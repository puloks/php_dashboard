<?php
	$connect = mysqli_connect("localhost", "root", "", "dashboard");
	if ( $connect ) {
		//echo "connected";
	}
	else{
	echo die("database connaction faild " . mysqli_error( $connect ));
	}
?>